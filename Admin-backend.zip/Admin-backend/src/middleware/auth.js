const { firebaseAuth } = require('./firebaseAuth');

module.exports = firebaseAuth; 